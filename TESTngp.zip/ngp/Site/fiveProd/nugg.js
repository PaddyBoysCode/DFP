/****************************************************************
Welcome to your Web Application JavaScript file!
You can set FoxInCloud options below, and/or add your own JavaScript code (Prototype.js or jQuery flavors are welcome)
You share this file between nuggTest and nuggProd:
e.g. edit ...\site\nuggTest\nugg.js and, once tested OK, copy to ...\site\nuggProd\nugg.js
/!\ This file is UTF-8 encoded; use a text editor that supports UTF-8 such as: Sublime Text, NotePad++ or PSpad





*****************************************************************/
Object.extend(FoxInCloud, {

  CGI: 'nugg',
	// Application script map extension (application code by default)

	/****************************************************************
	FoxInCloud settings
	Override values (between ':' and ',') as you see fit
	Litterals syntax is he same as in VFP, except Boolean [true|false], Null [null] and Date [new Date(year, month, day[, hours[, minutes[, seconds)]]]]
	Please note: new options may appear in future FoxInCloud versions.
	To take advantage of a NEW OPTION in you existing application(s), just copy and paste into your nugg.js file(s), at the same place.
	
	
	
	
	
	*****************************************************************/

  requestTimeoutDev: 600,
	// DEVELOPMENT : request timeout delay in seconds
	// when delay times out, an alert appears in HTML page and request is lost
	// a faily long delay is recommended to let you enough time to debug any possible error
 
 	requestTimeoutProd: 25,
	// PRODUCTION: request timeout delay in seconds 
	// when delay times out, an alert appears in HTML page and request is lost
	// set a delay at least as long as the 'Timeout' value in your wc.ini file

  requestWaitPic: true,
	// Request: display server response wait indicator image
	// you may change wait indicator image in your sub-class of aw.vcx!awFrm

  requestWaitPicDelay: .3,
	// request: delay in seconds before displaying server response wait indicator -- <=0 display right away

  requestFormOpacity: .9,
	// request: % opacity applied to form during request -- <=0 or > 1 to leave 100% opacity

  autoBlurDelay: 20,
	// <input type="text..."> (VFP textbox): delay in seconds for auto-sumit to server -- <=0 to cancel
	// Works only for VFP controls having .wlValidAutoNot = .F.

  inputAlwaysBlurOnReturn: false,
	// <input type="text ..."/> (VFP textbox): always send value to server when user hits 'enter' key, even if value has not changed

  inputTextDateSelector: 'input.awDate',
	// <input type="text"/> displaying a date: CSS selector 
  // FoxInCloud automatically sets class="awDate" to textBoxes displaying a date (licensed users: modify command awHTML > awHTMLgen.getHTML_txt())

  dateSeparator: '/',
	// <input type="text"/> displaying a date: separator

  dateFormat: 'day/month', // 'day/month' || 'month/day'
  // <input type="text"/> displaying a date: input format

  centuryRollover: 20,
	// <input type="text"/> displaying a date: Substract a century to dates whose year is > current year + this.centuryRollover

  inputTextBackColor: false,
	// <input type="text"/>: change background-color automatically 

  gridRowChangeDelay: 0.5,
	// grid: when user navigates rows using keyboard (up/down arrows), delay in seconds before sending row change event to the server -- <=0 to send right away

  gridRowChangeDelayClicked: 0,
  // grid: when user navigates rows using mouse, delay in seconds before sending row change event to the server -- <=0 to send right away

  gridColChangeDelay: 0.5,
  // grid: delay in seconds before sending column change event -- <=0 to send right away

  gridDateEmpty: '/ /',
	// Chain displayed in grid cells having a isNull(date) or Empty(date)  

  gridDateTimeEmpty: '/ / ::',
	// Chain displayed in grid cells having a isNull(dateTime) or Empty(dateTime)  

  pageEffectUser: true,
	// pageFrame: run a transition effect when page is activated by user

  pageEffectServer: true,
	// pageFrame: run a transition effect when page is activated by server

  visibleEffect: true, // V 2.10
  // run an transition effect when visibility of an object changes

  imgSrcEffect: true, // V 2.10
  // image: run a transition effect when image source changes

  effectDuration: 1.5, // V 2.10
  // default transition effect duration in seconds

  customErrorMsgHeader: function(standardErrorMsgHeader){ // V 2.10
  },
  // Any not empty value returned by this method overrides FoxInCloud's standard error message header
  // ["Sorry, FoxInCloud server produced an unexpected error..."]
  // Sample implementation (HTML is supported):
  // return '<p>your beloved application took a <i>slight break<i> ... <img src="images/foxincloud-logo-head-32.png">...<p>';

  customErrorMsgBody: function (standardErrorMsgBody){ // V 2.10
  },
  // Any not empty value returned by this method overrides FoxInCloud's standard error message body,
  // generated either on client (browser) side or on server side.
  // To see the kind of client side-error message FoxInCloud may generate, search 'this.Error' in FoxInCloud.js
  // Implementation Samples:
  // - sample 1: Replace 'FoxInCloud' by your client's name (/FoxInCloud/ig is a regular expression):
  // return standardErrorMsgBody.replace(/FoxInCloud/ig, 'Client Name');
  // - sample 2: Provide a standard error message (HTML is supported):
  // return '<p>Please contact your system administrator.</p>';

  customErrorMsgInDevMode: false, // V 2.10
  // To view this.customErrorMsgHeader() and this.customErrorMsgBody() results while developing your application (using URL such as http://localhost/nuggTest/...), set the above value to true.
  // Setting this to true is recommended while you implement/refine the this.customErrorMsgHeader() and/or this.customErrorMsgBody() methods above
  // * During Developement: any FoxInCloud standard error message takes precedence on what this.customErrorMsg*() return, unless you set this.customErrorMsgInDevMode to true
  // * In production: user always sees - if implemented - this.customErrorMsg*(), regardless of this.customErrorMsgInDevMode.
  // To easily test your this.customErrorMsg*(), open your browser's development tools (such as Firebug in Firefox) and type in the console command line:
  // FoxInCloud.Error(yourErrorMsgBody);

  onKeyLabels: "ctrl+A, ctrl+F, ctrl+O, ctrl+P, ctrl+S", // V 2.10
  // ON KEY LABEL combinations that you use in your VFP application and you want to inhibit the default browser behavior for.
  // (case insensitive)
  // this coma-separated list is dynamically parsed - you can modify it at any time during the course of an event by writing in VFP:
  // local loAJAX && as awAJAX of awServer.prg && full license
  // =wlAJAX(@m.loAJAX) and m.loAJAX.cScriptJSadd([FoxInCloud.onKeyLabels = FoxInCloud.onKeyLabels + ", ctrl+A, ctrl+F, ctrl+S, ctrl+O, ctrl+P, ctrl+Z";])
  // Note: not all browsers behave the same; test carefully! https://bugs.chromium.org/p/chromium/issues/detail?id=33056

  AttribSet_: function ( // V 2.20
    element
  , attribute
  , value
  ){
    // return true skips FoxInCloud default method
  },
  // Sets the value of an HTML element's attribute - shell method to be implemented in nugg.js

  RequestSend_ante: function ( // V 2.20
    url // URL to which the request is about to be sent 
  , element // HTML DOM element on which a user event occurred if any 
  , value // value of this element if any 
  , sync // request is being sent synchronously 
  ) {
  // your code here
  },
  // Executes just before sending a request to the server.
  // you can use this method to add parameters to the post envelope; to do so, add code such as:
  // this.parameters['someKey'] = someValue;
  // on server side, your VFP code can read these parameters anywhere using:
  // local oRequest as wwRequest of wwRequest.prg
  // someValue = iif(wlRequest(@m.oRequest), Cast(m.oRequest.Form('someKey') as <destination type>), .null.)
  // /!\ dates require a prior conversion to a VFP date literal:
  // this.parameters['someKey'] = this.RequestSend_sDate(someJavaScriptDate);
  // you could also (with extreme caution) override a parameter set by FoxInCloud; eg:
  // this.parameters['vpw'] = document.documentElement.clientWidth * 1.5; // ViewPortWidth // fakes a larger display area

  junk: null // simple place holder, leave it here 
});


/****************************************************************
Here comes any extra javascript code for your application ...

*****************************************************************/
